import pygame

pygame.init()

window = pygame.display.set_mode((1280, 720))

tick = 0
count = 4660000

font = pygame.font.Font(None, 25)

upgrades = 0

while count < 1000000000000000000000000000000000000000000000000000000000000000000000000:

    clock = pygame.time.Clock()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            if upgrades == 0: count += 1

            elif upgrades == 1: count += 2
            
            elif upgrades == 2: count += 5
                
            elif upgrades == 3: count += 10
                
            elif upgrades == 4: count += 15
                
            elif upgrades == 5: count += 50
                
            elif upgrades == 6: count += 60
                
            elif upgrades == 7: count += 75
                
            elif upgrades == 8: count += 100
                
            elif upgrades == 9: count += 150
                
            elif upgrades == 10: count += 1000
                
            elif upgrades == 11: count += 100000
            
            else: count += 1
        
        if keys[pygame.K_n]:
            if upgrades == 10 and count > 1500000:
                count -= 1500000
                upgrades += 1
            elif upgrades == 9 and count > 750000:
                count -= 750000
                upgrades += 1
            elif upgrades == 8 and count > 500000:
                count -= 500000
                upgrades += 1
            elif upgrades == 7 and count > 450000:
                count -= 450000
                upgrades += 1
            elif upgrades == 6 and count > 400000:
                count -= 400000
                upgrades += 1
            elif upgrades == 5 and count > 350000:
                count -= 350000
                upgrades += 1
            elif upgrades == 4 and count > 300000:
                count -= 300000
                upgrades += 1
            elif upgrades == 3 and count > 150000:
                count -= 150000
                upgrades += 1
            elif upgrades == 2 and count > 100000:
                count -= 100000
                upgrades += 1
            elif upgrades == 1 and count > 50000:
                count -= 50000
                upgrades += 1
            elif upgrades == 0 and count > 10000:
                count -= 10000
                upgrades += 1

    count_display = font.render('score: ' + str(count), True, 'white')
    grass_display = font.render('go touch some grass', True, 'white')
    air_display = font.render('BREATH SOME REAL AIR', True, 'white')
    upgrade_text = font.render('press n to upgrade', True, 'white')
    why_text = font.render('WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE WHY ARE YOU HERE', True, 'white')

    window.fill('black')
    if upgrades == 0:
        if count > 1000:
            window.blit(grass_display, (10, 25))
    elif upgrades <= 1:
        if count >= 10000:
            window.blit(air_display, (10, 40))
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 2:
        if count >= 50000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 3:
        if count >= 100000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 4:
        if count >= 150000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 5:
        if count >= 300000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 6:
        if count >= 350000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 7:
        if count >= 400000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 8:
        if count >= 450000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 9:
        if count >= 500000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades <= 10:
        if count >= 750000:
            window.blit(upgrade_text, (500, 300))
    elif upgrades < 11:
        if count >= 1500000:
            window.blit(upgrade_text, (500, 300))

    if upgrades == 11:
        window.blit(why_text, (0, 15))
        window.blit(why_text, (0, 25))
        window.blit(why_text, (0, 35))
        window.blit(why_text, (0, 45))
        window.blit(why_text, (0, 55))
        window.blit(why_text, (0, 65))
        window.blit(why_text, (0, 75))
        window.blit(why_text, (0, 85))
        window.blit(why_text, (0, 95))
        window.blit(why_text, (0, 105))
        window.blit(why_text, (0, 115))
        window.blit(why_text, (0, 125))
        window.blit(why_text, (0, 135))
        window.blit(why_text, (0, 145))
        window.blit(why_text, (0, 155))
        window.blit(why_text, (0, 165))
        window.blit(why_text, (0, 175))
        window.blit(why_text, (0, 185))
        window.blit(why_text, (0, 195))
        window.blit(why_text, (0, 205))
        window.blit(why_text, (0, 215))
        window.blit(why_text, (0, 225))
        window.blit(why_text, (0, 235))
        window.blit(why_text, (0, 245))
        window.blit(why_text, (0, 255))
        window.blit(why_text, (0, 265))
        window.blit(why_text, (0, 275))
        window.blit(why_text, (0, 285))
        window.blit(why_text, (0, 295))
        window.blit(why_text, (0, 305))
        window.blit(why_text, (0, 315))
        window.blit(why_text, (0, 325))
        window.blit(why_text, (0, 335))
        window.blit(why_text, (0, 345))
        window.blit(why_text, (0, 355))
        window.blit(why_text, (0, 365))
        window.blit(why_text, (0, 375))
        window.blit(why_text, (0, 385))
        window.blit(why_text, (0, 395))
        window.blit(why_text, (0, 405))
        window.blit(why_text, (0, 415))
        window.blit(why_text, (0, 425))
        window.blit(why_text, (0, 435))
        window.blit(why_text, (0, 445))
        window.blit(why_text, (0, 455))
        window.blit(why_text, (0, 465))
        window.blit(why_text, (0, 475))
        window.blit(why_text, (0, 485))
        window.blit(why_text, (0, 495))
        window.blit(why_text, (0, 505))
        window.blit(why_text, (0, 515))
        window.blit(why_text, (0, 525))
        window.blit(why_text, (0, 535))
        window.blit(why_text, (0, 545))
        window.blit(why_text, (0, 555))
        window.blit(why_text, (0, 565))
        window.blit(why_text, (0, 575))
        window.blit(why_text, (0, 585))
        window.blit(why_text, (0, 595))
        window.blit(why_text, (0, 605))
        window.blit(why_text, (0, 615))
        window.blit(why_text, (0, 625))
        window.blit(why_text, (0, 635))
        window.blit(why_text, (0, 645))
        window.blit(why_text, (0, 655))
        window.blit(why_text, (0, 665))
        window.blit(why_text, (0, 675))
        window.blit(why_text, (0, 685))
        window.blit(why_text, (0, 695))
        window.blit(why_text, (0, 705))
        window.blit(why_text, (0, 715))
        window.blit(why_text, (0, 725))
        window.blit(why_text, (0, 735))
        window.blit(why_text, (0, 745))
        window.blit(why_text, (0, 755))
        window.blit(why_text, (0, 765))
        window.blit(why_text, (0, 775))
        window.blit(why_text, (0, 785))
        window.blit(why_text, (0, 795))
        window.blit(why_text, (0, 805))

    if count > 1000:
        window.blit(grass_display, (10, 25))
    if count >= 10000:
        window.blit(air_display, (10, 40))

    window.blit(count_display, (10, 10))
    pygame.display.update()
    clock.tick(60)